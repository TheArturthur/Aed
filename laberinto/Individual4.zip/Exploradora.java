package aed.laberinto;

import es.upm.aedlib.lifo.*;


public class Exploradora {

/**
 * Busca un tesoro en el laberinto, empezando en el lugar
 * inicial: inicialLugar. 
 * @return un Objeto tesoro encontrado, o null, si ningun
 * tesoro existe en la parte del laberinto que es alcanzable
 * desde la posicion inicial.
 */
  public static Object explora(Lugar inicialLugar) {
    LIFO<Lugar> faltaPorExplorar = new LIFOList<Lugar>();
  
    // Modificar el resto de este metodo
    return null;
  }
}
