package aed.laberinto;

public class RunOneTest {
  public static void main(String args[]) {
    TesterInd4.test_5();
  }
}
